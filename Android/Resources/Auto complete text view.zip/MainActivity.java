package com.example.autocomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {


    private static final String[] colors = new String[]{"Violate","Indigo", "Blue", "Green", "Yellow", "Orange", "Red" };
    private static final String[] bikes = new String[]{"Pulsar", "Pulsar NS 250", "Honda", "Splender", "Tvs", "Duke", "Fz", "Yamaha"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final AutoCompleteTextView actv1 = (AutoCompleteTextView) findViewById(R.id.actv1);
        final AutoCompleteTextView actv2 = (AutoCompleteTextView) findViewById(R.id.actv2);
        Button button = (Button) findViewById(R.id.btn1);
        TextView textView = (TextView) findViewById(R.id.tv1);
        ImageView imageView1 = (ImageView) findViewById(R.id.iv1);
        ImageView imageView2 = (ImageView) findViewById(R.id.iv2);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, colors);
        actv1.setAdapter(adapter1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, bikes);
        actv2.setAdapter(adapter2);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actv1.showDropDown();
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actv2.showDropDown();
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = actv1.getText().toString();
                String s2 = actv2.getText().toString();
                textView.setText(s1+" "+s2);
            }
        });
    }
}