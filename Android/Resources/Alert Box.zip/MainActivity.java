package com.example.alertbox;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    TextView txtName,txtAcc,txtBal;
    Button btnName,btnAcc,btnBal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtName=findViewById(R.id.txtName);
        txtAcc=findViewById(R.id.txtAcc);
        txtBal=findViewById(R.id.txtBal);
        btnName=findViewById(R.id.btnName);
        btnAcc=findViewById(R.id.btnAcc);
        btnBal=findViewById(R.id.btnBal);
        btnName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtName.setText("vishnu");
            }
        });
        btnAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtAcc.setText("SBI4131772XXXX");
            }
        });
        btnBal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Are You sure\nYou want to display balance in your account?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        txtBal.setText("5800");
                    }
                }).setNegativeButton("No",null);
                AlertDialog alert=builder.create();
                alert.show();
            }
        });
    }
}