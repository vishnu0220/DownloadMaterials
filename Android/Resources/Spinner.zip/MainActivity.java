package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText sname = findViewById(R.id.sname);
        EditText sbranch = findViewById(R.id.sbranch);
        Spinner syear = findViewById(R.id.syear);
        Button btn = findViewById(R.id.btn);
        TextView result = findViewById(R.id.result);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder s = new StringBuilder();
                if(sname.getText().toString().equals("") || sbranch.getText().toString().equals("") || syear.getSelectedItem().toString().equals("Choose Year")){
                    result.setText("Input fields cannot be empty!!");
                    result.setTextColor(Color.parseColor("#FF0000"));
                    result.setTypeface(Typeface.DEFAULT_BOLD);
                }
                else {
                    s.append("Your name is ");
                    s.append(sname.getText().toString());
                    s.append(" studying ");
                    s.append(syear.getSelectedItem());
                    s.append(" year in the ");
                    s.append(sbranch.getText().toString());
                    s.append(" Department");
                    result.setText(s);
                    result.setTextColor(Color.parseColor("#00FF00"));
                    result.setTypeface(Typeface.DEFAULT_BOLD);
                }
            }
        });
    }
}