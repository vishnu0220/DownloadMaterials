package com.example.mapexample;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap googleMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SupportMapFragment supportMapFragment=(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.showMap);
        supportMapFragment.getMapAsync(this);
    }
    public void onMapReady(@NonNull GoogleMap googleMap1)
    {
        googleMap=googleMap1;
        LatLng Nandyal=new LatLng(15.4800,78.4800);
        googleMap.addMarker(new MarkerOptions().position(Nandyal).title("Nandyal"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(Nandyal));
    }
}