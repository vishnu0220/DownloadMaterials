package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity implements SensorEventListener {
    long l = 0;
    TextView x, y, z, countValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        x = (TextView)findViewById(R.id.x);
        y = (TextView)findViewById(R.id.y);
        z = (TextView)findViewById(R.id.z);
        countValue = (TextView) findViewById(R.id.count);

        SensorManager sensorManager=(SensorManager) getSystemService(SENSOR_SERVICE);
        if(sensorManager!=null) {
            Sensor accleroSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if(accleroSensor!=null) {
                sensorManager.registerListener(this,accleroSensor,SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
        else {
            Toast.makeText(this,"sensor service is not detected",Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        l++;
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            x.setText("X val :"+event.values[0]);
            y.setText("Y val :"+event.values[1]);
            z.setText("Z val :"+event.values[2]);
            countValue.setText("Movement in sensor got detected for " + l + " times");
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
