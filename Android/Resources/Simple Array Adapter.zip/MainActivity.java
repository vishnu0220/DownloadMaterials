package com.example.simplearray;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = (ListView) findViewById(R.id.display);
        String [] names = {"C", "C++", "Java", "Python", "Dbms", "Daa", "Ap"};
        ArrayAdapter <String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.one_ui, R.id.textview1, names);
        listView.setAdapter(arrayAdapter);
    }
}